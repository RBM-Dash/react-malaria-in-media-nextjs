import React from 'react';
import ArticleCard from './ArticleCard';

const MainContent = ({ kpiData, articles, onCardClick, currentLanguage }) => {
  return (
    <main className="main-content-component">
      <div className="kpis">
        {kpiData.map((kpi, index) => (
          <div className="kpi-card" key={`${kpi.label}-${index}`}>
            <span>{kpi.value}</span>
            <br />
            <small>{kpi.label}</small>
          </div>
        ))}
      </div>
      <div className="content-cards">
        {articles.map((article, index) => (
          <ArticleCard key={`${article.uniqueId}-${index}`} article={article} onClick={onCardClick} currentLanguage={currentLanguage} />
        ))}
      </div>
    </main>
  );
};

export default MainContent;