const regionData = {
    "Africa": ["africa", "african"],
    "Latin America": ["latin america", "south america", "central america", "latam"],
    "Caribbean": ["caribbean"],
    "Asia": ["asia", "asian", "southeast asia"],
    "North America": ["north america", "american"],
    "Europe": ["europe", "european"]
};

const countryData = {
    "Nigeria": { "risk": "High", "cities": ["lagos", "abuja", "kano", "ibadan", "port harcourt", "kaduna"], "demonyms": ["nigerian"] },
    "Democratic Republic of Congo": { "risk": "High", "cities": ["kinshasa", "lubumbashi", "mbuji-mayi", "kisangani"], "demonyms": ["congolese"] },
    "Ethiopia": { "risk": "High", "cities": ["addis ababa", "dire dawa", "mekelle", "gondar", "hawassa"], "demonyms": ["ethiopian"] },
    "Uganda": { "risk": "High", "cities": ["kampala", "gulu", "lira", "mbarara", "jinja"], "demonyms": ["ugandan"] },
    "Kenya": { "risk": "Low-Moderate", "cities": ["nairobi", "mombasa", "kisumu", "nakuru", "eldoret"], "demonyms": ["kenyan"] },
    "Tanzania": { "risk": "High", "cities": ["dar es salaam", "dodoma", "mwanza", "arusha", "mbeya"], "demonyms": ["tanzanian"] },
    "Zambia": { "risk": "High", "cities": ["lusaka", "ndola", "kitwe", "livingstone"], "demonyms": ["zambian"] },
    "Zimbabwe": { "risk": "Low-Moderate", "cities": ["harare", "bulawayo", "chitungwiza", "mutare"], "demonyms": ["zimbabwean"] },
    "Mozambique": { "risk": "High", "cities": ["maputo", "matola", "beira", "nampula"], "demonyms": ["mozambican"] },
    "Angola": { "risk": "High", "cities": ["luanda", "huambo", "lobito", "benguela"], "demonyms": ["angolan"] },
    "Ghana": { "risk": "High", "cities": ["accra", "kumasi", "tamale", "cape coast"], "demonyms": ["ghanian"] },
    "Burkina Faso": { "risk": "High", "cities": ["ouagadougou", "bobo-dioulasso"], "demonyms": ["burkinabe"] },
    "Mali": { "risk": "High", "cities": ["bamako", "sikasso", "mopti"], "demonyms": ["malian"] },
    "Niger": { "risk": "High", "cities": ["niamey", "zinder", "maradi"], "demonyms": ["nigerien"] },
    "Chad": { "risk": "High", "cities": ["ndjamena", "moundou", "sarh"], "demonyms": ["chadian"] },
    "Senegal": { "risk": "Low-Moderate", "cities": ["dakar", "touba", "thies"], "demonyms": ["senegalese"] },
    "Guinea": { "risk": "High", "cities": ["conakry", "nzerekore", "kankan"], "demonyms": ["guinean"] },
    "Ivory Coast": { "risk": "Low-Moderate", "cities": ["abidjan", "bouake", "daloa", "yamoussoukro"], "demonyms": ["ivorian"] },
    "Liberia": { "risk": "Low-Moderate", "cities": ["monrovia", "gbarnga"], "demonyms": ["liberian"] },
    "Sierra Leone": { "risk": "High", "cities": ["freetown", "bo", "kenema"], "demonyms": ["sierra leonean"] },
    "Gambia": { "risk": "Low-Moderate", "cities": ["banjul", "serekunda"], "demonyms": ["gambian"] },
    "Guinea-Bissau": { "risk": "Low-Moderate", "cities": ["bissau"], "demonyms": ["guinea-bissauan"] },
    "Cape Verde": { "risk": "Low-Moderate", "cities": ["praia", "mindelo"], "demonyms": ["cape verdean"] },
    "Equatorial Guinea": { "risk": "Low-Moderate", "cities": ["malabo", "bata"], "demonyms": ["equatoguinean"] },
    "Gabon": { "risk": "Low-Moderate", "cities": ["libreville", "port-gentil"], "demonyms": ["gabonese"] },
    "Republic of Congo": { "risk": "Low-Moderate", "cities": ["brazzaville", "pointe-noire"], "demonyms": ["congolese"] },
    "Cameroon": { "risk": "Low-Moderate", "cities": ["yaounde", "douala", "garoua", "bamenda"], "demonyms": ["cameroonian"] },
    "Central African Republic": { "risk": "High", "cities": ["bangui"], "demonyms": ["central african"] },
    "Rwanda": { "risk": "Low-Moderate", "cities": ["kigali", "butare", "gitarama"], "demonyms": ["rwandan"] },
    "Burundi": { "risk": "Low-Moderate", "cities": ["bujumbura", "gitega"], "demonyms": ["burundian"] },
    "Djibouti": { "risk": "Low-Moderate", "cities": ["djibouti"], "demonyms": ["djiboutian"] },
    "Somalia": { "risk": "Low-Moderate", "cities": ["mogadishu", "hargeisa", "bosaso"], "demonyms": ["somali"] },
    "Eritrea": { "risk": "Low-Moderate", "cities": ["asmara", "keren"], "demonyms": ["eritrean"] },
    "Sudan": { "risk": "Low-Moderate", "cities": ["khartoum", "omdurman", "port sudan", "kassala"], "demonyms": ["sudanese"] },
    "South Sudan": { "risk": "Low-Moderate", "cities": ["juba", "wau", "malakal"], "demonyms": ["south sudanese"] },
    "Madagascar": { "risk": "Low-Moderate", "cities": ["antananarivo", "toamasina", "antsirabe", "fianarantsoa"], "demonyms": ["malagasy"] },
    "Mauritius": { "risk": "Low-Moderate", "cities": ["port louis"], "demonyms": ["mauritian"] },
    "Comoros": { "risk": "Low-Moderate", "cities": ["moroni"], "demonyms": ["comoran"] },
    "Seychelles": { "risk": "Low-Moderate", "cities": ["victoria"], "demonyms": ["seychellois"] },
    "Sao Tome and Principe": { "risk": "Low-Moderate", "cities": ["sao tome"], "demonyms": ["sao tomean"] },
    "India": { "risk": "Moderate", "cities": ["mumbai", "delhi", "bangalore", "hyderabad", "chennai", "kolkata", "pune", "ahmedabad", "jaipur", "lucknow", "kanpur", "nagpur", "bhubaneswar", "raipur", "ranchi"], "demonyms": ["indian"] },
    "Indonesia": { "risk": "Moderate", "cities": ["jakarta", "surabaya", "medan", "bandung", "bekasi", "palembang", "makassar", "semarang", "jayapura", "manado"], "demonyms": ["indonesian"] },
    "Myanmar": { "risk": "High", "cities": ["yangon", "mandalay", "naypyidaw", "mawlamyine"], "demonyms": ["myanma"] },
    "Bangladesh": { "risk": "Moderate", "cities": ["dhaka", "chittagong", "sylhet", "rajshahi", "khulna", "cox's bazar"], "demonyms": ["bangladeshi"] },
    "Pakistan": { "risk": "Moderate", "cities": ["islamabad", "karachi", "lahore", "faisalabad", "rawalpindi", "multan", "peshawar", "quetta"], "demonyms": ["pakistani"] },
    "Afghanistan": { "risk": "Low-Moderate", "cities": ["kabul", "kandahar", "herat", "mazar-i-sharif"], "demonyms": ["afghan"] },
    "Cambodia": { "risk": "Moderate", "cities": ["phnom penh", "siem reap", "battambang"], "demonyms": ["cambodian"] },
    "Laos": { "risk": "Moderate", "cities": ["vientiane", "savannakhet", "pakse"], "demonyms": ["lao"] },
    "Vietnam": { "risk": "Moderate", "cities": ["hanoi", "ho chi minh city", "da nang", "can tho", "hai phong"], "demonyms": ["vietnamese"] },
    "Thailand": { "risk": "Moderate", "cities": ["bangkok", "chiang mai", "phuket", "hat yai"], "demonyms": ["thai"] },
    "Malaysia": { "risk": "Moderate", "cities": ["kuala lumpur", "george town", "johor bahru", "kota kinabalu", "kuching"], "demonyms": ["malaysian"] },
    "Philippines": { "risk": "Moderate", "cities": ["manila", "quezon city", "davao", "cebu city", "zamboanga", "cagayan de oro"], "demonyms": ["filipino"] },
    "Papua New Guinea": { "risk": "High", "cities": ["port moresby", "lae", "mount hagen"], "demonyms": ["papua new guinean"] },
    "Solomon Islands": { "risk": "High", "cities": ["honiara"], "demonyms": ["solomon islander"] },
    "Vanuatu": { "risk": "Low-Moderate", "cities": ["port vila"], "demonyms": ["vanuatuan"] },
    "Fiji": { "risk": "Low-Moderate", "cities": ["suva"], "demonyms": ["fijian"] },
    "Brazil": { "risk": "Moderate", "cities": ["brasilia", "sao paulo", "rio de janeiro", "salvador", "fortaleza", "belo horizonte", "manaus", "curitiba", "recife", "porto alegre", "belem", "goiania", "campo grande", "macapa", "rio branco", "boa vista", "porto velho", "palmas"], "demonyms": ["brazilian"] },
    "Colombia": { "risk": "Moderate", "cities": ["bogota", "medellin", "cali", "barranquilla", "cartagena", "bucaramanga", "pereira", "santa marta", "villavicencio", "pasto", "monteria", "valledupar", "neiva", "armenia", "popayan", "sincelejo", "florencia", "riohacha", "yopal", "arauca", "puerto carreno", "leticia", "inirida", "mitu"], "demonyms": ["colombian"] },
    "Venezuela": { "risk": "Moderate", "cities": ["caracas", "maracaibo", "valencia", "barquisimeto", "maracay", "ciudad guayana", "maturin", "barcelona", "cumana", "merida", "puerto la cruz", "petare", "turmero", "barinas", "trujillo", "acarigua", "valera", "punto fijo", "los teques", "guanare", "san cristobal", "cabimas", "coro", "ciudad bolivar"], "demonyms": ["venezuelan"] },
    "Guyana": { "risk": "Low-Moderate", "cities": ["georgetown", "linden", "new amsterdam"], "demonyms": ["guyanese"] },
    "Suriname": { "risk": "Low-Moderate", "cities": ["paramaribo", "lelydorp", "nieuw nickerie"], "demonyms": ["surinamese"] },
    "French Guiana": { "risk": "Low-Moderate", "cities": ["cayenne", "saint-laurent-du-maroni"], "demonyms": ["french guianese"] },
    "Peru": { "risk": "Moderate", "cities": ["lima", "arequipa", "trujillo", "chiclayo", "piura", "iquitos", "cusco", "chimbote", "huancayo", "tacna", "ica", "sullana", "ayacucho", "cajamarca", "pucallpa", "huanuco", "tarapoto", "tumbes", "jaen", "moyobamba", "bagua", "chachapoyas", "yurimaguas"], "demonyms": ["peruvian"] },
    "Bolivia": { "risk": "Moderate", "cities": ["la paz", "santa cruz", "cochabamba", "sucre", "oruro", "tarija", "potosi", "trinidad", "cobija"], "demonyms": ["bolivian"] },
    "Panama": { "risk": "Moderate", "cities": ["panama city", "san miguelito", "tocumen", "david", "arraijan", "colon", "la chorrera", "santiago", "chitra", "las tablas"], "demonyms": ["panamanian"] },
    "Costa Rica": { "risk": "Low-Moderate", "cities": ["san jose", "cartago", "puntarenas", "limon", "alajuela", "heredia", "liberia"], "demonyms": ["costa rican"] },
    "Nicaragua": { "risk": "Low-Moderate", "cities": ["managua", "leon", "masaya", "matagalpa", "chinandega", "granada", "jinotega", "esteli", "nueva guinea", "bluefields", "puerto cabezas"], "demonyms": ["nicaraguan"] },
    "Honduras": { "risk": "Moderate", "cities": ["tegucigalpa", "san pedro sula", "choloma", "la ceiba", "el progreso", "comayagua", "puerto cortes", "siguatepeque", "tocoa", "juticalpa", "catacamas", "choluteca", "danli", "olanchito", "santa rosa de copan", "yoro", "tela", "roatan"], "demonyms": ["honduran"] },
    "Guatemala": { "risk": "Moderate", "cities": ["guatemala city", "mixco", "villa nueva", "petapa", "quetzaltenango", "villa canales", "escuintla", "chinautla", "chimaltenango", "huehuetenango", "amatitlan", "santa lucia cotzumalguapa", "puerto barrios", "coban", "san marcos", "antigua guatemala", "jalapa", "retalhuleu", "mazatenango", "zacapa", "chiquimula", "flores"], "demonyms": ["guatemalan"] },
    "Belize": { "risk": "Low-Moderate", "cities": ["belize city", "san ignacio", "belmopan", "orange walk", "corozal", "dangriga", "punta gorda"], "demonyms": ["belizean"] },
    "El Salvador": { "risk": "Low-Moderate", "cities": ["san salvador", "soyapango", "santa ana", "san miguel", "mejicanos", "santa tecla", "apopa", "delgado", "san marcos", "usulutan", "cojutepeque", "ilopango", "chalatenango", "ahuachapan", "sonsonate", "la union", "zacatecoluca"], "demonyms": ["salvadoran"] },
    "Haiti": { "risk": "Moderate", "cities": ["port-au-prince", "carrefour", "delmas", "cap-haitien", "petionville", "gonaives", "saint-marc", "les cayes", "port-de-paix", "jacmel", "limbe", "fort-liberte", "hinche", "petit-goave", "mirebalais", "jeremie"], "demonyms": ["haitian"] },
    "Dominican Republic": { "risk": "Low-Moderate", "cities": ["santo domingo", "santiago", "santo domingo oeste", "santo domingo este", "san pedro de macoris", "la romana", "san cristobal", "puerto plata", "san francisco de macoris", "higüey", "concepcion de la vega", "moca", "bani", "bonao", "barahona", "mao", "monte cristi", "azua", "nagua", "esperanza"], "demonyms": ["dominican"] },
    "Saudi Arabia": { "risk": "Low-Moderate", "cities": ["riyadh", "jeddah", "mecca", "medina", "dammam", "khobar", "tabuk", "abha", "khamis mushait", "najran", "jazan", "al-baha", "hail", "al-qassim", "dhahran", "qatif", "hafar al-batin"], "demonyms": ["saudi"] },
    "Yemen": { "risk": "Low-Moderate", "cities": ["sanaa", "aden", "taiz", "hodeidah", "ibb", "dhamar", "mukalla", "hajjah", "amran", "saada", "al-bayda", "zinjibar", "al-mahwit", "marib", "shabwah", "al-jawf", "hadramawt", "lahij", "abyan", "al-daleh"], "demonyms": ["yemeni"] },
    "Oman": { "risk": "Low-Moderate", "cities": ["muscat", "sohar", "salalah", "nizwa", "sur", "bahla", "ibri", "rustaq", "buraimi", "khasab", "adam", "samail", "ibra", "bidiya", "duqm"], "demonyms": ["omani"] },
    "Iran": { "risk": "Low-Moderate", "cities": ["tehran", "mashhad", "isfahan", "karaj", "shiraz", "tabriz", "qom", "ahvaz", "kermanshah", "urmia", "rasht", "zahedan", "kerman", "nazarabad", "yazd", "ardabil", "bandar abbas", "eslamshahr", "zanjan", "hamadan", "azadshahr", "takestan", "khomeini shahr", "malard", "shahriar"], "demonyms": ["iranian"] },
    "Malawi": { "risk": "High", "cities": [], "demonyms": ["malawian"] },
    "Mauritania": { "risk": "Low-Moderate", "cities": [], "demonyms": ["mauritanian"] },
    "Benin": { "risk": "Low-Moderate", "cities": [], "demonyms": ["beninese"] },
    "Togo": { "risk": "Low-Moderate", "cities": [], "demonyms": ["togolese"] },
    "Botswana": { "risk": "Low-Moderate", "cities": [], "demonyms": ["botswanan"] },
    "Namibia": { "risk": "Low-Moderate", "cities": [], "demonyms": ["namibian"] },
    "Swaziland": { "risk": "Low-Moderate", "cities": [], "demonyms": ["swazi"] },
    "Timor-Leste": { "risk": "Low-Moderate", "cities": [], "demonyms": ["timorese"] },
    "Nepal": { "risk": "Low-Moderate", "cities": [], "demonyms": ["nepalese"] },
    "Bhutan": { "risk": "Low-Moderate", "cities": [], "demonyms": ["bhutanese"] },
    "Sri Lanka": { "risk": "Low-Moderate", "cities": [], "demonyms": ["sri lankan"] },
    "North Korea": { "risk": "Low-Moderate", "cities": [], "demonyms": ["north korean"] },
    "China": { "risk": "Low-Moderate", "cities": [], "demonyms": ["chinese"] },
    "Ecuador": { "risk": "Moderate", "cities": [], "demonyms": ["ecuadorian"] },
    "Mexico": { "risk": "Low-Moderate", "cities": [], "demonyms": ["mexican"] },
    "Iraq": { "risk": "Low-Moderate", "cities": [], "demonyms": ["iraqi"] },
    "Syria": { "risk": "Low-Moderate", "cities": [], "demonyms": ["syrian"] },
    "Turkey": { "risk": "Low-Moderate", "cities": [], "demonyms": ["turkish"] }
};

const countryTermMap = new Map();

for (const [country, data] of Object.entries(countryData)) {
    // Add country name (lowercase)
    countryTermMap.set(country.toLowerCase(), { country, type: 'country' });

    // Add demonyms
    data.demonyms.forEach(demonym => {
        countryTermMap.set(demonym.toLowerCase(), { country, type: 'demonym' });
    });

    // Add cities
    data.cities.forEach(city => {
        countryTermMap.set(city.toLowerCase(), { country, type: 'city' });
    });
}

module.exports = { countryData, countryTermMap };