const { fetchDataAndSave } = require('./fetch_data.js');
fetchDataAndSave();